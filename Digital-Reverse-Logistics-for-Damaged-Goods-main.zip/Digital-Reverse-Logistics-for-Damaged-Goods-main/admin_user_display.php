<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Users</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #28a745;
            padding: 10px 0;
        }
        .dashboard a {
            text-decoration: none;
            color: #fff;
            padding: 10px 20px;
            margin: 0 5px;
            border-radius: 4px;
            background-color: #218838;
            font-size: 1em;
            text-align: center;
            transition: background-color 0.3s ease;
        }
        .dashboard a:hover {
            background-color: #1e7e34;
        }
    </style>
</head>
<body>
<div class="dashboard">
        <a href="main.php">Home Page</a>
        <a href="admin_user_display.php">User List</a>
        <a href="admin_returnitems_display.php">Return Items</a>
        <a href="admin_contactus.php">Contact_us Details</a>
        <a href="admin_login.php">Logout</a>
    </div>
    <h1>Users List</h1>
   

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>FirstName</th>
                <th>LastName</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Database connection details
            $servername = "localhost";
            $username = "root";
            $password = "fayaj@0106";
            $dbname = "login1";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Query to fetch all users
            $sql = "SELECT * FROM users1";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id"] . "</td>";
                    echo "<td>" . $row["firstName"] . "</td>";
                    echo "<td>" . $row["lastName"] . "</td>";
                    echo "<td>" . $row["email"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No users found</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>
</body>
</html>
