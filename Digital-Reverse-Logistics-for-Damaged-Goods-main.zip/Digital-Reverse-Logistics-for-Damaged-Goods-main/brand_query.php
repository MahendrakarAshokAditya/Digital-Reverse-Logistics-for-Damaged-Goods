<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "fayaj@0106";
$database = "return_items"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve a single column
$sql = "SELECT brand FROM product_returns"; // Replace `item_name` and `enquiries` with your table and column names
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Item List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #28a745;
            margin-bottom: 20px;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            background: #f4f4f4;
            margin: 10px 0;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            color: #333;
        }
        li:hover {
            background: #e9ecef;
            border-color: #28a745;
        }
    

        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #28a745;
            padding: 10px 0;
        }
        .dashboard a {
            text-decoration: none;
            color: #fff;
            padding: 10px 20px;
            margin: 0 5px;
            border-radius: 4px;
            background-color: #218838;
            font-size: 1em;
            text-align: center;
            transition: background-color 0.3s ease;
        }
        .dashboard a:hover {
            background-color: #1e7e34;
        }
    </style>
</head>
<body>
<div class="dashboard">
        <a href="main.php">Home Page</a>
        
        <a href="products_list_enquiry.php">Product List</a>
     
        <a href="enquiry_login.php">Logout</a>
    </div>
    <div class="container">
        <h2>Brand List</h2>
        <ul>
            <?php
            if ($result->num_rows > 0) {
                // Display each item in the list
                while ($row = $result->fetch_assoc()) {
                    echo "<li>" . htmlspecialchars($row['brand']) . "</li>";
                }
            } else {
                echo "<li>No items found.</li>";
            }
            ?>
        </ul>
    </div>
</body>
</html>
<?php
// Close connection
$conn->close();
?>
