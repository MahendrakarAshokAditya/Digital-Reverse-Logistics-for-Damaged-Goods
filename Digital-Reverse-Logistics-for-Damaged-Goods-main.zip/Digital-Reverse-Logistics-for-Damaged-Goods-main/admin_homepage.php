<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
        }

        .dashboard {
            display: flex;
            flex-direction: column;
            gap: 20px;
            width: 80%;
            max-width: 600px;
        }

        .block {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 40px;
            font-size: 20px;
            font-weight: bold;
            border-radius: 10px;
            text-decoration: none;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .block:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

    </style>
</head>
<body>
    <div class="dashboard">
        <a href="main.php" class="block">Home Page</a>
        <a href="admin_user_display.php" class="block">User List</a>
        <a href="admin_returnitems_display.php" class="block">Return Items</a>
        <a href="admin_contactus.php" class="block">Contact_us details</a>
        <a href="admin_login.php" class="block">Logout</a>
    </div>
</body>
</html>
