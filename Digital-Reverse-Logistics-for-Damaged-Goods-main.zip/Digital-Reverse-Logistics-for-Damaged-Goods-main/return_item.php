<?php
// Connect to MySQL Database
$servername = "localhost";
$username = "root";
$password = "fayaj@0106";
$database = "return_items";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_name = $_POST['product_name'];
    $brand = $_POST['brand'];
    $delivery_id = $_POST['delivery_id'];
    $delivery_date = $_POST['delivery_date'];
    $return_date = $_POST['return_date'];
    $price = $_POST['price'];
    $phone_number = $_POST['phone_number'];
    $bank_account_number = $_POST['bank_account_number'];

    // Insert into database
    $sql = "INSERT INTO product_returns(product_name, brand, delivery_id, delivery_date, return_date, price, phone_number, bank_account_number) 
            VALUES ('$product_name', '$brand', '$delivery_id', '$delivery_date', '$return_date', '$price', '$phone_number', '$bank_account_number')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Product return request submitted successfully.');</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #28a745;
            padding: 10px 0;
        }

        .dashboard a {
            text-decoration: none;
            color: #fff;
            padding: 10px 20px;
            margin: 0 5px;
            border-radius: 4px;
            background-color: #218838;
            font-size: 1em;
            text-align: center;
            transition: background-color 0.3s ease;
        }

        .dashboard a:hover {
            background-color: #1e7e34;
        }

        .form-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            width: 400px;
            margin: 20px auto;
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-group button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <a href="main.php">Home Page</a>
        <a href="return_item.php">Return Items</a>
        <a href="index.php">Logout</a>
    </div>

    <div class="form-container">
        <h2>Return Product</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="product_name">Product Name</label>
                <input type="text" id="product_name" name="product_name" required>
            </div>
            <div class="form-group">
                <label for="brand">Brand</label>
                <input type="text" id="brand" name="brand" required>
            </div>
            <div class="form-group">
                <label for="delivery_id">Delivery ID</label>
                <input type="text" id="delivery_id" name="delivery_id" required>
            </div>
            <div class="form-group">
                <label for="delivery_date">Delivery Date</label>
                <input type="date" id="delivery_date" name="delivery_date" required>
            </div>
            <div class="form-group">
                <label for="return_date">Return Date</label>
                <input type="date" id="return_date" name="return_date" required>
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" id="price" name="price" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="phone_number">Phone Number</label>
                <input type="text" id="phone_number" name="phone_number" required>
            </div>
            <div class="form-group">
                <label for="bank_account_number">Bank Account Number</label>
                <input type="text" id="bank_account_number" name="bank_account_number" required>
            </div>
            <div class="form-group">
                <button type="submit">Submit Return</button>
            </div>
        </form>
    </div>
</body>
</html>
