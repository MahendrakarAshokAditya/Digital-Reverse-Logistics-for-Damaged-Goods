<?php
// Database connection
$conn = new mysqli("localhost", "root", "fayaj@0106", "conatct_us");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch contact details
$sql = "SELECT id, name, email, message, submitted_at FROM contacts ORDER BY submitted_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us Submissions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        .container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #28a745;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            text-align: left;
            padding: 12px;
        }
        th {
            background-color: #28a745;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .no-data {
            text-align: center;
            color: #777;
            font-size: 1.2em;
            padding: 20px 0;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #28a745;
            padding: 10px 0;
        }
        .dashboard a {
            text-decoration: none;
            color: #fff;
            padding: 10px 20px;
            margin: 0 5px;
            border-radius: 4px;
            background-color: #218838;
            font-size: 1em;
            text-align: center;
            transition: background-color 0.3s ease;
        }
        .dashboard a:hover {
            background-color: #1e7e34;
        }
    </style>
</head>
<body>
    <div class="container">
    <div class="dashboard">
        <a href="main.php">Home Page</a>
        <a href="admin_user_display.php">User List</a>
        <a href="admin_returnitems_display.php">Return Items</a>
        <a href="admin_contactus.php">Contact_us Details</a>
        <a href="admin_login.php">Logout</a>
    </div>
    
        <h1>Contact Us Submissions</h1>
        <?php if ($result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Message</th>
                    <th>Submitted At</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row["id"]; ?></td>
                    <td><?php echo htmlspecialchars($row["name"]); ?></td>
                    <td><?php echo htmlspecialchars($row["email"]); ?></td>
                    <td><?php echo nl2br(htmlspecialchars($row["message"])); ?></td>
                    <td><?php echo $row["submitted_at"]; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p class="no-data">No submissions found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
<?php
$conn->close();
?>
