<?php
session_start();
include("enquiry_connect.php");

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <style>
           body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
        }

        .dashboard {
            display: flex;
            flex-direction: column;
            gap: 20px;
            width: 80%;
            max-width: 600px;
        }

        .block {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 40px;
            font-size: 20px;
            font-weight: bold;
            border-radius: 10px;
            text-decoration: none;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .block:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        </style>

</head>
<body>
    <div style="text-align:center; padding:15%;">
      <p  style="font-size:50px; font-weight:bold;">
       Hello  <?php 
       if(isset($_SESSION['email'])){
        $email=$_SESSION['email'];
        $query=mysqli_query($conn, "SELECT enquiry.* FROM `enquiry` WHERE enquiry.email='$email'");
        while($row=mysqli_fetch_array($query)){
            echo $row['firstName'].' '.$row['lastName'];
        }
       }
       ?>
       :)
      </p>
      <div class="dashboard">
        
        <a href="main.php" class="block">Home Page</a>
        <a href="products_list_enquiry.php" class="block">Product List</a>
        <a href="enquiry_login.php" class="block">Logout</a>
    </div>
      
    </div>
</body>
</html>