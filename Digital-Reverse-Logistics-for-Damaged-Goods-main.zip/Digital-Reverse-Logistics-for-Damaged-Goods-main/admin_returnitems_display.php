<?php
// Connect to MySQL Database
$servername = "localhost";
$username = "root";
$password = "fayaj@0106";
$database = "return_items";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch return items
$sql = "SELECT * FROM product_returns";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Items</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background: white;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        table th {
            background-color: #007bff;
            color: white;
            font-weight: bold;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: auto;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #28a745;
            padding: 10px 0;
        }
        .dashboard a {
            text-decoration: none;
            color: #fff;
            padding: 10px 20px;
            margin: 0 5px;
            border-radius: 4px;
            background-color: #218838;
            font-size: 1em;
            text-align: center;
            transition: background-color 0.3s ease;
        }
        .dashboard a:hover {
            background-color: #1e7e34;
        }
    </style>
</head>
<body>
    <div class="container">
    <div class="dashboard">
        <a href="main.php">Home Page</a>
        <a href="admin_user_display.php">User List</a>
        <a href="admin_returnitems_display.php">Return Items</a>
        <a href="admin_contactus.php">Contact_us Details</a>
        <a href="admin_login.php">Logout</a>
    </div>
        <h2>Returned Products</h2>
       

        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Product Name</th>
                        <th>Brand</th>
                        <th>Delivery ID</th>
                        <th>Delivery Date</th>
                        <th>Return Date</th>
                        <th>Price</th>
                        <th>Phone Number</th>
                        <th>Bank Account Number</th>
                        <th>Request Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['product_name']; ?></td>
                            <td><?php echo $row['brand']; ?></td>
                            <td><?php echo $row['delivery_id']; ?></td>
                            <td><?php echo $row['delivery_date']; ?></td>
                            <td><?php echo $row['return_date']; ?></td>
                            <td><?php echo $row['price']; ?></td>
                            <td><?php echo $row['phone_number']; ?></td>
                            <td><?php echo $row['bank_account_number']; ?></td>
                            <td><?php echo $row['created_at']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No returned products found.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>
