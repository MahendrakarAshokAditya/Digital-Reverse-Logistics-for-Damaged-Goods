<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reverse Logistics Solutions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        header, .section {
            padding: 40px 20px;
            text-align: center;
        }
        header {
            background-color: #28a745;
            color: #fff;
        }
        header h1 {
            font-size: 2.5em;
            margin: 0;
        }
        header p {
            margin: 10px 0 0;
            font-size: 1.1em;
        }
        .section img {
            max-width: 100%;
            height: auto;
            margin: 20px 0;
            border-radius: 10px;
        }
        .modules {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        .module-card {
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            padding: 20px;
            width: 250px;
            text-align: left;
        }
        .module-card h2 {
            color: #28a745;
            font-size: 1.5em;
        }
        .module-card p {
            color: #777;
            font-size: 0.9em;
            margin: 10px 0 20px;
        }
        .module-card a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
        }
        .module-card a:hover {
            background-color: #218838;
        }
        .contact {
            background-color: #f1f1f1;
            padding: 30px;
        }
        .contact h2 {
            color: #28a745;
            margin-bottom: 10px;
        }
        .contact p {
            color: #555;
            margin-bottom: 20px;
        }
        .contact form {
            max-width: 400px;
            margin: 0 auto;
            text-align: left;
        }
        .contact form input, 
        .contact form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1em;
        }
        .contact form button {
            background-color: #28a745;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
        }
        .contact form button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <header>
        <h1>Reverse Logistics Solutions</h1>
        <p>Efficient, Sustainable, and Innovative Solutions for Your Business</p>
    </header>
    <div class="section">
        <h2>About Reverse Logistics</h2>
        <img src="https://www.amsc-usa.com/wp-content/uploads/2023/11/a-graphic-showing-warehouse-workers-processing-returns-from-reverse-logistics.jpg" alt="Reverse Logistics Image">
        <p>Reverse logistics refers to the process of managing the return of goods and materials for the purposes of reuse, recycling, or proper disposal. 
           Our solutions help businesses streamline this process, ensuring sustainability and cost efficiency.</p>
    </div>
    <div class="section">
        <h2>Our Modules</h2>
        <p>Explore the core modules that drive our reverse logistics solution</p>
        <div class="modules">
            <?php
            $modules = [
                ["title" => "Admin", "description" => "Manage approvals, oversee operations, and ensure smooth workflows across all modules.", "link" => "admin_login.php"],
                ["title" => "Client", "description" => "Register, upload objectives, and monitor the status of your commodities seamlessly.", "link" => "index.php"],
                ["title" => "Enquiry", "description" => "Analyze and categorize commodities for refurbishing or recycling with precision.", "link" => "enquiry_login.php"],
                ["title" => "Warehouse", "description" => "Monitor, manage, and store processed commodities for efficient logistics.", "link" => "warehouse_login.php"]
            ];

            foreach ($modules as $module) {
                echo '
                <div class="module-card">
                    <h2>' . $module['title'] . '</h2>
                    <p>' . $module['description'] . '</p>
                    <a href="' . $module['link'] . '">Learn More</a>
                </div>';
            }
            ?>
        </div>
    </div>
    <div class="section contact">
        <h2>Contact Us</h2>
        <p>If you have any questions or need assistance, feel free to reach out to us.</p>
        <?php
        // Database connection
        $conn = new mysqli("localhost", "root", "fayaj@0106", "conatct_us");

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = $conn->real_escape_string($_POST["name"]);
            $email = $conn->real_escape_string($_POST["email"]);
            $message = $conn->real_escape_string($_POST["message"]);

            $sql = "INSERT INTO contacts (name, email, message) VALUES ('$name', '$email', '$message')";

            if ($conn->query($sql) === TRUE) {
                echo "<p style='color: green;'>Thank you! Your message has been sent.</p>";
            } else {
                echo "<p style='color: red;'>Error: " . $conn->error . "</p>";
            }
        }
        ?>
        <form method="post" action="">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <textarea name="message" placeholder="Your Message" rows="5" required></textarea>
            <button type="submit">Send Message</button>
        </form>
    </div>
</body>
</html>
