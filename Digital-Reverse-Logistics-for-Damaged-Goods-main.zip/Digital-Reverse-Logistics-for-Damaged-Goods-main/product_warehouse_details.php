<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "fayaj@0106";
$database = "employee_recycle_db"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employee_name = $_POST['employee_name'];
    $date_received = $_POST['date_received'];
    $recycle = $_POST['recycle'];
    $trash = $_POST['trash'];

    // Insert data into the database
    $sql = "INSERT INTO employee_recycle_trash (employee_name, date_received, recycle, trash)
            VALUES ('$employee_name', '$date_received', '$recycle', '$trash')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Form submitted successfully!');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Recycle/Trash Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input[type="text"], .form-group input[type="date"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group input[type="radio"] {
            margin-right: 10px;
        }
        .form-group button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #0056b3;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #28a745;
            padding: 10px 0;
        }
        .dashboard a {
            text-decoration: none;
            color: #fff;
            padding: 10px 20px;
            margin: 0 5px;
            border-radius: 4px;
            background-color: #218838;
            font-size: 1em;
            text-align: center;
            transition: background-color 0.3s ease;
        }
        .dashboard a:hover {
            background-color: #1e7e34;
        }
    </style>
</head>
<body>
    <div class="container">
    <div class="dashboard">
    <a href="main.php" class="block">Home Page</a>
        <a href="products_list_warehouse.php" class="block">Product List</a>
        <a href="product_warehouse_details.php" class="block">Report Details</a>
        <a href="products_warehouse_history.php" class="block">Report History</a>
        <a href="warehouse_login.php" class="block">Logout</a>
    </div>
        <h2>Employee Recycle/Trash Form</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="employee_name">Employee Name</label>
                <input type="text" id="employee_name" name="employee_name" required>
            </div>
            <div class="form-group">
                <label for="date_received">Date Received</label>
                <input type="date" id="date_received" name="date_received" required>
            </div>
            <div class="form-group">
                <label>Recycle</label>
                <input type="radio" id="recycle_yes" name="recycle" value="Yes" required>
                <label for="recycle_yes">Yes</label>
                <input type="radio" id="recycle_no" name="recycle" value="No">
                <label for="recycle_no">No</label>
            </div>
            <div class="form-group">
                <label>Trash</label>
                <input type="radio" id="trash_yes" name="trash" value="Yes" required>
                <label for="trash_yes">Yes</label>
                <input type="radio" id="trash_no" name="trash" value="No">
                <label for="trash_no">No</label>
            </div>
            <div class="form-group">
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>
</body>
</html>
