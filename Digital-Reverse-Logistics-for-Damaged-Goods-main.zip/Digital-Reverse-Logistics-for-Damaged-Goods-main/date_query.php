<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "fayaj@0106";
$database = "return_items"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$specific_date = "";
$result = null;

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $specific_date = $_POST['specific_date'];
    
    // Query to retrieve multiple columns for the specific date
    $sql = "SELECT brand, product_name, delivery_date, return_date, price FROM product_returns WHERE return_date = '$specific_date'";
    $result = $conn->query($sql);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Returns by Date</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #28a745;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #28a745;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f4f4f4;
        }
        .form-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-container input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 10px;
        }
        .form-container button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            background-color: #28a745;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: #218838;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #28a745;
            padding: 10px 0;
        }
        .dashboard a {
            text-decoration: none;
            color: #fff;
            padding: 10px 20px;
            margin: 0 5px;
            border-radius: 4px;
            background-color: #218838;
            font-size: 1em;
            text-align: center;
            transition: background-color 0.3s ease;
        }
        .dashboard a:hover {
            background-color: #1e7e34;
        }
    </style>
</head>
<body>
<div class="dashboard">
    <a href="main.php">Home Page</a>
    <a href="products_list_enquiry.php">Product List</a>
    <a href="enquiry_login.php">Logout</a>
</div>
<div class="container">
    <h2>Product Returns by Date</h2>
    <div class="form-container">
        <form method="POST" action="">
            <input type="date" name="specific_date" required value="<?php echo htmlspecialchars($specific_date); ?>">
            <button type="submit">Search</button>
        </form>
    </div>
    <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
        <?php if ($result && $result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Brand</th>
                        <th>Product Name</th>
                        <th>Delivery Date</th>
                        <th>Return Date</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['brand']); ?></td>
                            <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['delivery_date']); ?></td>
                            <td><?php echo htmlspecialchars($row['return_date']); ?></td>
                            <td><?php echo htmlspecialchars($row['price']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No items found for this date.</p>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>
<?php
// Close connection
$conn->close();
?>
